import { Terminal, Book, Play, RotateCcw, Backpack, CheckCircle2, AlertCircle, ChevronRight, ChevronDown, Star } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";

type Difficulty = "Basic" | "Basic II" | "Intermediate";

interface Challenge {
  id: number;
  title: string;
  difficulty: Difficulty;
  context: string;
  mission: string;
  query: string;
  reward: string;
  success_visual: string;
  failure_visual: string;
}

// Mock Data for Query Results
const TABLES = {
  supplies: [
    { id: 1, name: 'Cheddar', category: 'Cheese', quantity: 15, supplier_id: 101 },
    { id: 2, name: 'Swiss', category: 'Cheese', quantity: 8, supplier_id: 102 },
    { id: 3, name: 'Mozzarella', category: 'Cheese', quantity: 20, supplier_id: 101 },
    { id: 4, name: 'Brie', category: 'Cheese', quantity: 5, supplier_id: 103 },
    { id: 5, name: 'Gouda', category: 'Cheese', quantity: 12, supplier_id: 102 },
    { id: 6, name: 'Blue Cheese', category: 'Cheese', quantity: 4, supplier_id: 103 },
    { id: 7, name: 'Parmesan', category: 'Cheese', quantity: 18, supplier_id: 101 },
    { id: 8, name: 'Provolone', category: 'Cheese', quantity: 9, supplier_id: 102 },
    { id: 9, name: 'Feta', category: 'Cheese', quantity: 14, supplier_id: 103 },
    { id: 10, name: 'Havarti', category: 'Cheese', quantity: 7, supplier_id: 102 },
    { id: 11, name: 'Camembert', category: 'Cheese', quantity: 6, supplier_id: 103 },
    { id: 12, name: 'Gruyere', category: 'Cheese', quantity: 11, supplier_id: 102 },
    { id: 13, name: 'Roquefort', category: 'Cheese', quantity: 3, supplier_id: 103 },
    { id: 14, name: 'Manchego', category: 'Cheese', quantity: 10, supplier_id: 102 },
    { id: 15, name: 'Ricotta', category: 'Cheese', quantity: 16, supplier_id: 101 },
    { id: 16, name: 'Apple', category: 'Fruit', quantity: 25, supplier_id: 201 },
    { id: 17, name: 'Grapes', category: 'Fruit', quantity: 30, supplier_id: 201 },
    { id: 18, name: 'Bread', category: 'Bakery', quantity: 40, supplier_id: 301 },
    { id: 19, name: 'Crackers', category: 'Bakery', quantity: 50, supplier_id: 301 },
  ],
  suppliers: [
    { id: 101, name: 'Dairy King', city: 'Wisconsin' },
    { id: 102, name: 'Cheese Co.', city: 'Paris' },
    { id: 103, name: 'Fancy Foods', city: 'Rome' },
    { id: 201, name: 'Orchard Fresh', city: 'Washington' },
    { id: 301, name: 'Daily Bread', city: 'Berlin' },
  ]
};

const challenges: Challenge[] = [
  // BASIC
  {
    id: 1,
    title: "The Forgotten Inventory",
    difficulty: "Basic",
    context: "Moussie has just arrived at the pantry and wants to know what's there.",
    mission: "Show all supplies.",
    query: "SELECT * FROM supplies;",
    reward: "Cheddar",
    success_visual: "Moussie jumps for joy!",
    failure_visual: "Moussie looks confused."
  },
  {
    id: 2,
    title: "Only the Tastiest",
    difficulty: "Basic",
    context: "Moussie is looking for the names of essentials.",
    mission: "Select only the names of the supplies.",
    query: "SELECT name FROM supplies;",
    reward: "Swiss",
    success_visual: "Moussie nibbles happily.",
    failure_visual: "Moussie scratches her head."
  },
  {
    id: 3,
    title: "The Cheese Hunt",
    difficulty: "Basic",
    context: "Moussie has a specific craving.",
    mission: "Find all supplies that are in the category 'Cheese'.",
    query: "SELECT * FROM supplies WHERE category = 'Cheese';",
    reward: "Mozzarella",
    success_visual: "Moussie does a little dance.",
    failure_visual: "Moussie sighs."
  },
  {
    id: 4,
    title: "Stockpile Check",
    difficulty: "Basic",
    context: "We need to know what we have plenty of.",
    mission: "Find the names of supplies with a quantity greater than 10.",
    query: "SELECT name FROM supplies WHERE quantity > 10;",
    reward: "Brie",
    success_visual: "Moussie claps her paws.",
    failure_visual: "Moussie looks worried."
  },
  {
    id: 5,
    title: "Sorting the Stash",
    difficulty: "Basic",
    context: "Moussie wants to organize her favorite cheeses.",
    mission: "Show the cheeses ordered by quantity from highest to lowest.",
    query: "SELECT * FROM supplies WHERE category = 'Cheese' ORDER BY quantity DESC;",
    reward: "Gouda",
    success_visual: "Moussie organizes the shelf.",
    failure_visual: "Moussie trips over a wheel."
  },
  // BASIC II
  {
    id: 6,
    title: "Counting Calories",
    difficulty: "Basic II",
    context: "How many items do we have in total?",
    mission: "Count the total number of supplies.",
    query: "SELECT COUNT(*) FROM supplies;",
    reward: "Blue Cheese",
    success_visual: "Moussie counts on her fingers.",
    failure_visual: "Moussie loses count."
  },
  {
    id: 7,
    title: "Average Abundance",
    difficulty: "Basic II",
    context: "What is the average quantity of our supplies?",
    mission: "Find the average quantity of all supplies.",
    query: "SELECT AVG(quantity) FROM supplies;",
    reward: "Parmesan",
    success_visual: "Moussie nods wisely.",
    failure_visual: "Moussie looks puzzled by the math."
  },
  {
    id: 8,
    title: "C-Food Diet",
    difficulty: "Basic II",
    context: "Moussie only wants foods starting with 'C'.",
    mission: "Find supplies where the name starts with 'C'.",
    query: "SELECT * FROM supplies WHERE name LIKE 'C%';",
    reward: "Provolone",
    success_visual: "Moussie points to the C foods.",
    failure_visual: "Moussie can't find the letter C."
  },
  {
    id: 9,
    title: "Variety Pack",
    difficulty: "Basic II",
    context: "Moussie wants a mix of Cheese and Fruit.",
    mission: "Find supplies in categories 'Cheese' or 'Fruit'.",
    query: "SELECT * FROM supplies WHERE category IN ('Cheese', 'Fruit');",
    reward: "Feta",
    success_visual: "Moussie juggles cheese and fruit.",
    failure_visual: "Moussie drops a fruit."
  },
  {
    id: 10,
    title: "Distinct Tastes",
    difficulty: "Basic II",
    context: "What categories of food do we have?",
    mission: "Select distinct categories from supplies.",
    query: "SELECT DISTINCT category FROM supplies;",
    reward: "Havarti",
    success_visual: "Moussie lists the categories.",
    failure_visual: "Moussie repeats herself."
  },
  // INTERMEDIATE
  {
    id: 11,
    title: "Category Count",
    difficulty: "Intermediate",
    context: "How many items are in each category?",
    mission: "Count the number of supplies per category.",
    query: "SELECT category, COUNT(*) FROM supplies GROUP BY category;",
    reward: "Camembert",
    success_visual: "Moussie makes a chart.",
    failure_visual: "Moussie gets tangled in data."
  },
  {
    id: 12,
    title: "Plentiful Pantries",
    difficulty: "Intermediate",
    context: "Which categories have a total quantity greater than 50?",
    mission: "Find categories with total quantity > 50.",
    query: "SELECT category, SUM(quantity) FROM supplies GROUP BY category HAVING SUM(quantity) > 50;",
    reward: "Gruyere",
    success_visual: "Moussie celebrates the abundance.",
    failure_visual: "Moussie looks at empty shelves."
  },
  {
    id: 13,
    title: "Source of Supply",
    difficulty: "Intermediate",
    context: "Moussie wants to know who supplies each item.",
    mission: "Join supplies and suppliers to show item name and supplier name.",
    query: "SELECT supplies.name, suppliers.name FROM supplies JOIN suppliers ON supplies.supplier_id = suppliers.id;",
    reward: "Roquefort",
    success_visual: "Moussie shakes hands with suppliers.",
    failure_visual: "Moussie gets lost in the map."
  },
  {
    id: 14,
    title: "Parisian Picks",
    difficulty: "Intermediate",
    context: "Moussie only wants cheese from Paris.",
    mission: "Find names of supplies from suppliers in 'Paris'.",
    query: "SELECT supplies.name FROM supplies JOIN suppliers ON supplies.supplier_id = suppliers.id WHERE suppliers.city = 'Paris';",
    reward: "Manchego",
    success_visual: "Moussie wears a beret.",
    failure_visual: "Moussie misses the train."
  },
  {
    id: 15,
    title: "The Grand Feast",
    difficulty: "Intermediate",
    context: "Moussie wants a huge feast of Cheese or specific treats.",
    mission: "Find supplies where category is 'Cheese' AND (quantity > 50 OR name LIKE '%Blue%').",
    query: "SELECT * FROM supplies WHERE category = 'Cheese' AND (quantity > 50 OR name LIKE '%Blue%');",
    reward: "Ricotta",
    success_visual: "Moussie prepares a banquet.",
    failure_visual: "Moussie burns the dinner."
  }
];

const CheeseIcon = ({ type, className }: { type: string, className?: string }) => {
  const commonClasses = `w-full h-full ${className || ""}`;
  
  switch (type) {
    // BASIC
    case "Cheddar": // Orange Wedge
      return (
        <svg viewBox="0 0 24 24" className={commonClasses} fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M3 12L21 4L21 20H3V12Z" fill="#FFA000" stroke="#E65100" strokeWidth="2" strokeLinejoin="round"/>
          <circle cx="10" cy="14" r="1.5" fill="#FFECB3" opacity="0.6"/>
          <circle cx="16" cy="10" r="1" fill="#FFECB3" opacity="0.6"/>
        </svg>
      );
    case "Swiss": // Yellow Slice with holes
      return (
        <svg viewBox="0 0 24 24" className={commonClasses} fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M4 6H20V18H4V6Z" fill="#FFEB3B" stroke="#FBC02D" strokeWidth="2"/>
          <circle cx="8" cy="10" r="1.5" fill="#FFF9C4"/>
          <circle cx="14" cy="14" r="2" fill="#FFF9C4"/>
          <circle cx="16" cy="8" r="1" fill="#FFF9C4"/>
        </svg>
      );
    case "Mozzarella": // White Ball
      return (
        <svg viewBox="0 0 24 24" className={commonClasses} fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="12" cy="12" r="8" fill="#FFF" stroke="#E0E0E0" strokeWidth="2"/>
          <path d="M12 4C14 4 16 6 16 12" stroke="#F5F5F5" strokeWidth="1"/>
        </svg>
      );
    case "Brie": // White Wedge with rind
      return (
        <svg viewBox="0 0 24 24" className={commonClasses} fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M4 14L12 6L20 14H4Z" fill="#FFF9C4" stroke="#D7CCC8" strokeWidth="2"/>
          <path d="M4 14L12 18L20 14" fill="#EFEBE9" stroke="#D7CCC8" strokeWidth="2"/>
        </svg>
      );
    case "Gouda": // Red Wheel
      return (
        <svg viewBox="0 0 24 24" className={commonClasses} fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="12" cy="12" r="9" fill="#FFD54F" stroke="#FFA000" strokeWidth="2"/>
          <path d="M12 3C7 3 3 7 3 12H21C21 7 17 3 12 3Z" fill="#E53935" stroke="#C62828" strokeWidth="2"/>
        </svg>
      );
    
    // BASIC II
    case "Blue Cheese": // White with blue spots
      return (
        <svg viewBox="0 0 24 24" className={commonClasses} fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M3 12L21 4L21 20H3V12Z" fill="#FFF" stroke="#90CAF9" strokeWidth="2"/>
          <path d="M8 12L10 14M15 8L17 10M12 16L14 18" stroke="#1E88E5" strokeWidth="2" strokeLinecap="round"/>
        </svg>
      );
    case "Parmesan": // Hard Yellow Wedge
      return (
        <svg viewBox="0 0 24 24" className={commonClasses} fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M6 20L18 16L18 4L6 8V20Z" fill="#FFE082" stroke="#FFB300" strokeWidth="2"/>
          <path d="M6 8L18 4" stroke="#FFB300" strokeWidth="2"/>
        </svg>
      );
    case "Provolone": // Pale Yellow Cylinder
      return (
        <svg viewBox="0 0 24 24" className={commonClasses} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="6" y="6" width="12" height="14" rx="2" fill="#FFF59D" stroke="#FBC02D" strokeWidth="2"/>
          <path d="M6 10H18" stroke="#FBC02D" strokeWidth="1" strokeDasharray="2 2"/>
          <path d="M12 4V6" stroke="#8D6E63" strokeWidth="2"/>
        </svg>
      );
    case "Feta": // White Block
      return (
        <svg viewBox="0 0 24 24" className={commonClasses} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="4" y="6" width="16" height="12" fill="#FFF" stroke="#BDBDBD" strokeWidth="2"/>
          <path d="M8 6V18M12 6V18M16 6V18" stroke="#EEEEEE" strokeWidth="1"/>
        </svg>
      );
    case "Havarti": // Pale Yellow Slice with small holes
      return (
        <svg viewBox="0 0 24 24" className={commonClasses} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="4" y="4" width="16" height="16" rx="2" fill="#FFF9C4" stroke="#FBC02D" strokeWidth="2"/>
          <circle cx="8" cy="8" r="0.5" fill="#F9A825"/>
          <circle cx="16" cy="16" r="0.5" fill="#F9A825"/>
          <circle cx="12" cy="12" r="0.5" fill="#F9A825"/>
        </svg>
      );

    // INTERMEDIATE
    case "Camembert": // Round White Box
      return (
        <svg viewBox="0 0 24 24" className={commonClasses} fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="12" cy="12" r="9" fill="#FFF" stroke="#8D6E63" strokeWidth="2"/>
          <circle cx="12" cy="12" r="7" stroke="#D7CCC8" strokeWidth="1" strokeDasharray="4 4"/>
        </svg>
      );
    case "Gruyere": // Yellow darker wedge
      return (
        <svg viewBox="0 0 24 24" className={commonClasses} fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M3 12L21 4L21 20H3V12Z" fill="#FDD835" stroke="#F9A825" strokeWidth="2"/>
        </svg>
      );
    case "Roquefort": // Blue/Green spots
      return (
        <svg viewBox="0 0 24 24" className={commonClasses} fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M4 14L12 6L20 14H4Z" fill="#FFF" stroke="#90CAF9" strokeWidth="2"/>
          <circle cx="10" cy="11" r="1" fill="#00897B"/>
          <circle cx="14" cy="12" r="1.5" fill="#00897B"/>
        </svg>
      );
    case "Manchego": // Zigzag rind wedge
      return (
        <svg viewBox="0 0 24 24" className={commonClasses} fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M3 12L21 4L21 20H3V12Z" fill="#FFF176" stroke="#FBC02D" strokeWidth="2"/>
          <path d="M21 4L21 20" stroke="#5D4037" strokeWidth="4" strokeDasharray="2 2"/>
        </svg>
      );
    case "Ricotta": // White mound in bowl
      return (
        <svg viewBox="0 0 24 24" className={commonClasses} fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M4 14C4 18.4 7.6 22 12 22C16.4 22 20 18.4 20 14" fill="#BCAAA4" stroke="#5D4037" strokeWidth="2"/>
          <path d="M5 14C5 10 8 7 12 7C16 7 19 10 19 14" fill="#FFF" stroke="#E0E0E0" strokeWidth="2"/>
        </svg>
      );
    default:
      return <div className="w-full h-full bg-yellow-400 rounded-full" />;
  }
};

const getMockResult = (id: number): any[] | null => {
  const { supplies, suppliers } = TABLES;
  switch (id) {
    case 1: return supplies;
    case 2: return supplies.map(s => ({ name: s.name }));
    case 3: return supplies.filter(s => s.category === 'Cheese');
    case 4: return supplies.filter(s => s.quantity > 10).map(s => ({ name: s.name }));
    case 5: return supplies.filter(s => s.category === 'Cheese').sort((a, b) => b.quantity - a.quantity);
    case 6: return [{ count: supplies.length }];
    case 7: return [{ avg: Math.round(supplies.reduce((acc, s) => acc + s.quantity, 0) / supplies.length) }];
    case 8: return supplies.filter(s => s.name.startsWith('C'));
    case 9: return supplies.filter(s => ['Cheese', 'Fruit'].includes(s.category));
    case 10: return Array.from(new Set(supplies.map(s => s.category))).map(c => ({ category: c }));
    case 11: {
      const counts: Record<string, number> = {};
      supplies.forEach(s => counts[s.category] = (counts[s.category] || 0) + 1);
      return Object.entries(counts).map(([category, count]) => ({ category, count }));
    }
    case 12: {
      const sums: Record<string, number> = {};
      supplies.forEach(s => sums[s.category] = (sums[s.category] || 0) + s.quantity);
      return Object.entries(sums).filter(([_, sum]) => sum > 50).map(([category, sum]) => ({ category, sum }));
    }
    case 13: return supplies.map(s => {
      const supplier = suppliers.find(sup => sup.id === s.supplier_id);
      return { name: s.name, supplier: supplier?.name };
    });
    case 14: return supplies.filter(s => {
      const supplier = suppliers.find(sup => sup.id === s.supplier_id);
      return supplier?.city === 'Paris';
    }).map(s => ({ name: s.name }));
    case 15: return supplies.filter(s => s.category === 'Cheese' && (s.quantity > 50 || s.name.includes('Blue')));
    default: return null;
  }
};

export function HomePage() {
  const [query, setQuery] = useState("");
  const [output, setOutput] = useState<string | null>(null);
  const [queryResult, setQueryResult] = useState<any[] | null>(null);
  const [pipState, setPipState] = useState<"idle" | "happy" | "confused">("idle");
  const [activeChallengeId, setActiveChallengeId] = useState<number>(1);
  const [inventory, setInventory] = useState<Record<string, number>>({});
  const [showReward, setShowReward] = useState<string | null>(null);
  const [showPenalty, setShowPenalty] = useState<boolean>(false);

  const activeChallenge = challenges.find(c => c.id === activeChallengeId) || challenges[0];

  const runQuery = () => {
    const normalize = (str: string) => 
      str.trim().replace(/;\s*$/, "").replace(/\s+/g, " ").toLowerCase();

    const normalizedInput = normalize(query);
    const normalizedExpected = normalize(activeChallenge.query);

    if (normalizedInput === normalizedExpected) {
      setPipState("happy");
      setOutput(`Success! \n\nReward Unlocked: ${activeChallenge.reward}`);
      setQueryResult(getMockResult(activeChallenge.id));
      
      // Add to inventory
      const reward = activeChallenge.reward;
      setInventory(prev => ({
        ...prev,
        [reward]: (prev[reward] || 0) + 1
      }));
      
      // Trigger animation
      setShowReward(reward);
      setTimeout(() => setShowReward(null), 2000);

    } else {
      const reward = activeChallenge.reward;
      
      // Always show penalty animation on failure
      setShowPenalty(true);
      setTimeout(() => setShowPenalty(false), 2000);
      setQueryResult(null);

      // Penalty logic
      setInventory(prev => {
        const rewardCount = prev[reward] || 0;
        
        // Prefer losing reward type
        if (rewardCount > 0) {
           return {
             ...prev,
             [reward]: rewardCount - 1
           };
        }
        
        // Else decrement first available type
        const availableType = Object.keys(prev).find(type => (prev[type] || 0) > 0);
        if (availableType) {
           return {
             ...prev,
             [availableType]: (prev[availableType] || 0) - 1
           };
        }

        return prev;
      });

      // Calculate lost message based on current state (will be updated in next render)
      const totalCurrentCheese = Object.values(inventory).reduce((a, b) => a + b, 0);
      const willLoseCheese = totalCurrentCheese > 0;
      const lostMsg = willLoseCheese ? "\n\nYou lost 1 cheese" : "";
      
      setOutput(`Fizzle! The spell didn't work.\n\nThe correct spell is: ${activeChallenge.query}${lostMsg}`);
    }
  };

  const totalCheese = Object.values(inventory).reduce((a, b) => a + b, 0);

  return (
    <div className="min-h-screen bg-[#4E342E] text-[#F1F8E9] font-sans selection:bg-[#8BC34A] selection:text-[#1B262C]">
      {/* Reward Animation Overlay */}
      {showReward && (
        <div className="fixed inset-0 z-50 pointer-events-none flex items-center justify-center">
          <div className="animate-in zoom-in slide-in-from-bottom-10 fade-in duration-1000 fill-mode-forwards flex flex-col items-center">
            <div className="w-32 h-32 drop-shadow-2xl filter brightness-110">
              <CheeseIcon type={showReward} />
            </div>
            <div className="text-4xl font-bold text-[#FFD54F] mt-4 text-shadow-lg animate-bounce">
              +1 {showReward}
            </div>
          </div>
        </div>
      )}

      {/* Penalty Animation Overlay */}
      {showPenalty && (
        <div className="fixed inset-0 z-50 pointer-events-none flex items-center justify-center">
          <div className="animate-in zoom-in slide-in-from-bottom-10 fade-in duration-1000 fill-mode-forwards flex flex-col items-center">
            <div className="text-8xl drop-shadow-2xl filter brightness-110">
              🧀
            </div>
            <div className="text-4xl font-bold text-[#FF5252] mt-4 text-shadow-lg animate-bounce">
              You lost 1 cheese
            </div>
          </div>
        </div>
      )}

      {/* Top Bar / Hub */}
      <header className="h-16 border-b-4 border-[#3E2723] bg-[#5D4037] flex items-center justify-between px-4 md:px-6 shadow-lg relative z-10">
        <div className="flex items-center gap-3">
          <div className="bg-[#8BC34A] p-2 rounded-full border-2 border-[#33691E]">
            <Terminal className="w-5 h-5 text-[#1B262C]" />
          </div>
          <h1 className="text-xl font-bold tracking-wide text-[#FFD54F] drop-shadow-sm hidden sm:block">SQL Cottage</h1>
        </div>
        
        <div className="flex-1 mx-4 md:mx-8">
          <div className="flex items-center gap-2 text-sm font-medium text-[#C5E1A5] mb-1">
            <span className="hidden sm:inline">Level 1: Moussie's Grand Pantry</span>
            <span className="sm:hidden">Level 1</span>
            <span className="ml-auto flex items-center gap-1">
              {activeChallengeId}/15 <Star className="w-3 h-3 fill-current" />
            </span>
          </div>
          <div className="h-3 bg-[#3E2723] rounded-full overflow-hidden border border-[#8D6E63]">
            <div 
              className="h-full bg-[#8BC34A] rounded-full relative transition-all duration-500"
              style={{ width: `${(activeChallengeId / 15) * 100}%` }}
            >
              <div className="absolute inset-0 bg-white/20 animate-pulse"></div>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <Sheet>
            <SheetTrigger asChild>
              <Button className="flex items-center gap-2 bg-[#3E2723] px-3 py-1.5 rounded-lg border border-[#8D6E63] hover:bg-[#4E342E] h-auto">
                <div className="text-[#FFD54F]">🧀</div>
                <span className="font-bold text-[#FFD54F]">{totalCheese}</span>
                <Backpack className="w-5 h-5 text-[#C5E1A5] ml-2" />
              </Button>
            </SheetTrigger>
            <SheetContent className="bg-[#5D4037] border-l-4 border-[#3E2723] text-[#F1F8E9] overflow-y-auto">
              <SheetHeader>
                <SheetTitle className="text-[#FFD54F] font-serif text-2xl">Moussie's Backpack</SheetTitle>
              </SheetHeader>
              <div className="mt-6 space-y-6">
                {Object.entries(inventory).length === 0 ? (
                  <div className="text-center text-[#C5E1A5] italic p-8 border-2 border-dashed border-[#8D6E63] rounded-xl">
                    Your backpack is empty. <br/>Solve puzzles to earn cheese!
                  </div>
                ) : (
                  <div className="grid grid-cols-2 gap-4">
                    {Object.entries(inventory).map(([type, count]) => count > 0 && (
                      <div key={type} className="bg-[#3E2723] p-3 rounded-xl border border-[#8D6E63] flex flex-col items-center gap-2 relative">
                        <div className="absolute top-2 right-2 bg-[#8BC34A] text-[#1B262C] text-xs font-bold px-1.5 py-0.5 rounded-full min-w-[20px] text-center">
                          {count}
                        </div>
                        <div className="w-12 h-12">
                          <CheeseIcon type={type} />
                        </div>
                        <span className="text-xs font-bold text-[#FFD54F] text-center leading-tight">{type}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="container mx-auto p-3 lg:p-4 min-h-[calc(100vh-64px)] flex flex-col lg:grid lg:grid-cols-12 gap-3 lg:gap-4">
        
        {/* Left Column: Moussie's Corner */}
        <section className="col-span-12 lg:col-span-3 flex flex-col gap-4 order-3 lg:order-1">
          <Card className="flex-1 bg-[#5D4037] border-4 border-[#3E2723] shadow-xl relative overflow-hidden flex flex-col items-center justify-center p-3 lg:p-4 min-h-[250px] lg:min-h-[320px] rounded-2xl">
            <div className="absolute top-0 left-0 w-full h-2 bg-[#3E2723]/50"></div>
            
            {/* Moussie Avatar Placeholder */}
            <div className={`w-24 h-24 lg:w-32 lg:h-32 rounded-full border-4 border-[#8D6E63] bg-[#3E2723] overflow-hidden relative mb-4 transition-all duration-500 ${pipState === 'happy' ? 'scale-110 ring-4 ring-[#FFD54F]' : ''} ${pipState === 'confused' ? 'rotate-[-5deg]' : ''}`}>
              <div className="w-full h-full bg-gradient-to-b from-[#8D6E63] to-[#4E342E] flex items-center justify-center relative">
                 {/* Geometric Mouse Placeholder - Enhanced */}
                 <div className={`relative mt-3 transition-transform duration-300 ${pipState === 'happy' ? '-translate-y-2' : ''} scale-75 lg:scale-90`}>
                    {/* Ears with inner shading */}
                    <div className="absolute -top-8 -left-8 w-14 h-14 bg-gradient-to-br from-[#6D4C41] to-[#3E2723] rounded-full border-4 border-[#3E2723] shadow-lg">
                      <div className="absolute inset-2 bg-[#8D6E63] rounded-full opacity-50"></div>
                    </div>
                    <div className="absolute -top-8 -right-8 w-14 h-14 bg-gradient-to-bl from-[#6D4C41] to-[#3E2723] rounded-full border-4 border-[#3E2723] shadow-lg">
                      <div className="absolute inset-2 bg-[#8D6E63] rounded-full opacity-50"></div>
                    </div>
                    
                    {/* Head with gradient */}
                    <div className="w-24 h-20 bg-gradient-to-b from-[#A1887F] to-[#8D6E63] rounded-[50%_50%_45%_45%] relative z-10 border-4 border-[#3E2723] flex flex-col items-center justify-center shadow-xl">
                       {/* Eyes with shine */}
                       <div className="flex gap-3 mb-1">
                          <div className={`w-3 h-3 bg-[#3E2723] rounded-full relative ${pipState === 'confused' ? 'translate-y-1' : ''}`}>
                            <div className="absolute top-0.5 right-0.5 w-1 h-1 bg-white rounded-full"></div>
                          </div>
                          <div className={`w-3 h-3 bg-[#3E2723] rounded-full relative ${pipState === 'confused' ? '-translate-y-1' : ''}`}>
                            <div className="absolute top-0.5 right-0.5 w-1 h-1 bg-white rounded-full"></div>
                          </div>
                       </div>
                       {/* Snout Area */}
                       <div className="flex flex-col items-center mt-1">
                          <div className="w-5 h-3 bg-[#FFAB91] rounded-full mb-1 shadow-sm"></div>
                          {/* Whiskers */}
                          <div className="w-16 h-px bg-[#3E2723]/30 absolute top-12"></div>
                          <div className="w-16 h-px bg-[#3E2723]/30 absolute top-13 rotate-6"></div>
                          <div className="w-16 h-px bg-[#3E2723]/30 absolute top-13 -rotate-6"></div>
                       </div>
                       
                       {/* Mouth */}
                       <div className={`w-3 h-1.5 border-b-2 border-[#3E2723] rounded-full ${pipState === 'happy' ? 'h-2 border-b-4' : ''}`}></div>
                    </div>
                 </div>
              </div>
            </div>

            <div className="text-center space-y-1 mb-2">
              <h2 className="text-xl font-bold text-[#FFD54F]">Moussie</h2>
              <p className="text-[#C5E1A5] italic text-xs px-2 leading-tight">
                {pipState === 'idle' && "\"I'm ready for a snack!\""}
                {pipState === 'happy' && activeChallenge.success_visual}
                {pipState === 'confused' && activeChallenge.failure_visual}
              </p>
            </div>

            <div className="mt-auto w-full bg-[#3E2723]/50 p-2 rounded-lg border border-[#8D6E63]/50">
              <h3 className="text-[10px] font-bold uppercase tracking-wider text-[#A1887F] mb-1">Status</h3>
              <div className="flex items-center gap-2 text-xs">
                {pipState === 'idle' && <span className="text-[#F1F8E9]">Waiting...</span>}
                {pipState === 'happy' && <span className="text-[#8BC34A] font-bold flex items-center gap-1"><CheckCircle2 className="w-3 h-3"/> Success!</span>}
                {pipState === 'confused' && <span className="text-[#FFB74D] font-bold flex items-center gap-1"><AlertCircle className="w-3 h-3"/> Confused...</span>}
              </div>
            </div>
          </Card>
        </section>

        {/* Center Column: The Magic Terminal */}
        <section className="col-span-12 lg:col-span-5 flex flex-col gap-3 order-2 lg:order-2">
          <Card className="flex-1 bg-[#263238] border-[6px] border-[#3E2723] shadow-2xl rounded-2xl overflow-hidden flex flex-col relative min-h-[250px] p-0">
            {/* Terminal Header */}
            <div className="bg-[#37474F] p-2 flex items-center justify-between border-b border-[#455A64]">
              <div className="flex items-center gap-1.5">
                <div className="w-2.5 h-2.5 rounded-full bg-[#FF5252]"></div>
                <div className="w-2.5 h-2.5 rounded-full bg-[#FFD740]"></div>
                <div className="w-2.5 h-2.5 rounded-full bg-[#69F0AE]"></div>
              </div>
              <span className="text-[10px] font-mono text-[#90A4AE]">magic_stone_v1.0</span>
            </div>

            {/* Code Editor Area */}
            <div className="flex-1 p-3 lg:p-4 font-mono text-sm lg:text-base text-[#C3E88D] relative">
              <textarea 
                className="w-full h-full bg-transparent resize-none focus:outline-none placeholder-[#546E7A]"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                spellCheck={false}
                placeholder="-- Enter your spell (SQL query) here..."
              />
              <div className="absolute bottom-2 right-3 text-[10px] text-[#546E7A]">
                Ln 1, Col {query.length}
              </div>
            </div>

            {/* Output Area (if present) */}
            {(output || queryResult) && (
              <div className="h-1/3 bg-[#1B262C] border-t border-[#455A64] flex flex-col animate-in slide-in-from-bottom-2">
                {/* Result Header */}
                <div className="p-2 border-b border-[#455A64] bg-[#263238] flex justify-between items-center shrink-0">
                   <span className={`text-xs font-bold ${pipState === 'confused' ? 'text-[#FF8A80]' : 'text-[#80CBC4]'}`}>
                     {pipState === 'confused' ? 'Error Output' : 'Query Result'}
                   </span>
                   {queryResult && <span className="text-[10px] text-[#546E7A]">{queryResult.length} rows</span>}
                </div>
                
                <div className="flex-1 overflow-auto p-3 font-mono text-xs">
                  {/* Text Message */}
                  {output && (
                    <div className={`whitespace-pre-wrap mb-3 ${pipState === 'confused' ? 'text-[#FF8A80]' : 'text-[#80CBC4]'}`}>
                      {output}
                    </div>
                  )}

                  {/* Table Data */}
                  {queryResult && (
                    <div className="overflow-x-auto">
                      <table className="w-full text-left border-collapse">
                        <thead>
                          <tr>
                            {Object.keys(queryResult[0] || {}).map(key => (
                              <th key={key} className="border-b border-[#546E7A] pb-1 text-[#80CBC4] uppercase tracking-wider pr-4">{key}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {queryResult.map((row, i) => (
                            <tr key={i} className="group hover:bg-[#37474F] transition-colors">
                              {Object.values(row).map((val: any, j) => (
                                <td key={j} className="py-1 pr-4 text-[#C3E88D] border-b border-[#37474F] group-hover:border-[#546E7A] whitespace-nowrap">
                                  {val}
                                </td>
                              ))}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              </div>
            )}
          </Card>

          {/* Action Bar */}
          <div className="flex items-center justify-between bg-[#5D4037] p-3 rounded-2xl border-4 border-[#3E2723] shadow-lg">
             <Button 
              variant="outline" 
              size="sm"
              className="bg-[#3E2723] text-[#A1887F] border-[#8D6E63] hover:bg-[#4E342E] hover:text-[#F1F8E9] h-9"
              onClick={() => { setQuery(""); setOutput(null); setQueryResult(null); setPipState("idle"); }}
            >
              <RotateCcw className="w-3.5 h-3.5 mr-1.5" />
              Reset
            </Button>
            
            <Button 
              size="sm" 
              className="bg-[#8BC34A] text-[#1B262C] hover:bg-[#7CB342] border-b-4 border-[#558B2F] active:border-b-0 active:translate-y-1 font-bold text-base px-6 h-10 transition-all"
              onClick={runQuery}
            >
              <Play className="w-4 h-4 mr-2 fill-current" />
              Cast Spell
            </Button>
          </div>
        </section>

        {/* Right Column: The Grimoire */}
        <section className="col-span-12 lg:col-span-4 flex flex-col gap-4 order-1 lg:order-3">
          <Card className="flex-1 bg-[#F1F8E9] border-4 border-[#5D4037] shadow-xl relative overflow-hidden flex flex-col min-h-[250px] lg:min-h-[320px] p-0 rounded-2xl">
            {/* Book Binding Effect */}
            <div className="absolute left-0 top-0 bottom-0 w-3 bg-gradient-to-r from-[#3E2723] to-[#5D4037] z-10 rounded-l-2xl"></div>
            
            <div className="p-3 pl-8 lg:p-4 lg:pl-10 -ml-3 lg:-ml-5 flex-1 flex flex-col h-full rounded-2xl">
              <div className="flex items-center gap-2 mb-2 lg:mb-3 border-b-2 border-[#D7CCC8] pb-1.5">
                <Book className="w-4 h-4 text-[#5D4037]" />
                <h2 className="font-serif text-lg font-bold text-[#3E2723]">Grimoire</h2>
              </div>

              <ScrollArea className="flex-1 pr-3 -mr-3">
                <div className="space-y-3 lg:space-y-4 pr-3">
                  {/* Schema Section */}
                  <div className="mb-3 lg:mb-4">
                    <div className="bg-[#C5E1A5] px-3 py-2 rounded-lg mb-2 shadow-sm border border-[#AED581]">
                      <h3 className="text-xs font-bold text-[#33691E] uppercase tracking-wider flex items-center gap-2">
                        <div className="w-1.5 h-1.5 rounded-full bg-[#33691E]"></div>
                        Ingredients (Tables)
                      </h3>
                    </div>
                    
                    <div className="bg-white/80 p-2 rounded-lg border border-[#C5E1A5] shadow-sm ml-1">
                      <div className="flex items-center gap-2 font-mono text-xs font-bold text-[#3E2723]">
                        <span className="text-[#8BC34A]">table</span> supplies
                      </div>
                      <div className="mt-1 pl-3 text-[10px] text-[#5D4037] space-y-0.5 font-mono">
                        <div>id <span className="text-[#90A4AE]">INT</span></div>
                        <div>name <span className="text-[#90A4AE]">VARCHAR</span></div>
                        <div>category <span className="text-[#90A4AE]">VARCHAR</span></div>
                        <div>quantity <span className="text-[#90A4AE]">INT</span></div>
                        <div>supplier_id <span className="text-[#90A4AE]">INT</span></div>
                      </div>
                    </div>

                    <div className="bg-white/80 p-2 rounded-lg border border-[#C5E1A5] shadow-sm ml-1 mt-2">
                      <div className="flex items-center gap-2 font-mono text-xs font-bold text-[#3E2723]">
                        <span className="text-[#8BC34A]">table</span> suppliers
                      </div>
                      <div className="mt-1 pl-3 text-[10px] text-[#5D4037] space-y-0.5 font-mono">
                        <div>id <span className="text-[#90A4AE]">INT</span></div>
                        <div>name <span className="text-[#90A4AE]">VARCHAR</span></div>
                        <div>city <span className="text-[#90A4AE]">VARCHAR</span></div>
                      </div>
                    </div>
                  </div>

                  {/* Challenges List Grouped by Difficulty */}
                  <div>
                    <h3 className="text-[10px] font-bold text-[#5D4037] uppercase tracking-wider mb-1.5">Missions</h3>
                    <Accordion type="single" collapsible defaultValue="Basic" className="w-full space-y-2">
                      {(["Basic", "Basic II", "Intermediate"] as const).map((difficulty) => (
                        <AccordionItem key={difficulty} value={difficulty} className="border-0">
                          <AccordionTrigger className="bg-[#C5E1A5] hover:bg-[#AED581] px-3 py-2 rounded-lg text-[#33691E] font-bold text-xs h-auto shadow-sm border border-[#AED581] data-[state=open]:rounded-lg transition-all">
                            {difficulty} Spells
                          </AccordionTrigger>
                          <AccordionContent className="pt-2 pl-1 bg-transparent">
                             <div className="space-y-2">
                              {challenges.filter(c => c.difficulty === difficulty).map((challenge) => (
                                <div 
                                  key={challenge.id}
                                  className={`
                                    border rounded-xl transition-all duration-200 cursor-pointer overflow-hidden
                                    ${activeChallengeId === challenge.id 
                                      ? 'bg-[#FFF3E0] border-[#FFB74D] shadow-sm' 
                                      : 'bg-white border-[#D7CCC8] hover:border-[#A1887F] opacity-90 hover:opacity-100'}
                                  `}
                                  onClick={() => {
                                    setActiveChallengeId(challenge.id);
                                    setPipState("idle");
                                    setOutput(null);
                                  }}
                                >
                                  {/* Header */}
                                  <div className="p-1.5 lg:p-2 flex items-start gap-2">
                                    <div className={`
                                      mt-0.5 w-4 h-4 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0
                                      ${activeChallengeId === challenge.id ? 'bg-[#FF9800] text-white' : 'bg-[#D7CCC8] text-[#5D4037]'}
                                    `}>
                                      {challenge.id}
                                    </div>
                                    <div className="flex-1">
                                      <h4 className={`font-serif text-sm font-bold leading-tight ${activeChallengeId === challenge.id ? 'text-[#E65100]' : 'text-[#5D4037]'}`}>
                                        {challenge.title}
                                      </h4>
                                    </div>
                                    {activeChallengeId === challenge.id && <ChevronDown className="w-3 h-3 text-[#E65100]" />}
                                    {activeChallengeId !== challenge.id && <ChevronRight className="w-3 h-3 text-[#A1887F]" />}
                                  </div>

                                  {/* Expanded Content */}
                                  {activeChallengeId === challenge.id && (
                                    <div className="px-1.5 pb-1.5 lg:px-2 lg:pb-2 pt-0 text-xs space-y-1.5 animate-in slide-in-from-top-1">
                                      <p className="text-[#4E342E] italic border-l-2 border-[#FFB74D] pl-1.5 leading-relaxed">
                                        {challenge.context}
                                      </p>
                                      
                                      <div className="space-y-0.5">
                                        <span className="text-[10px] font-bold text-[#E65100] uppercase">Mission:</span>
                                        <p className="text-[#3E2723] font-medium leading-relaxed">{challenge.mission}</p>
                                      </div>

                                      <div className="bg-[#FFF8E1] p-1.5 rounded-lg border border-[#FFE0B2] text-[10px] flex items-center gap-1.5">
                                        <div className="w-5 h-5 shrink-0">
                                          <CheeseIcon type={challenge.reward} />
                                        </div>
                                        <div>
                                          <span className="font-bold text-[#F57C00]">Reward:</span> {challenge.reward}
                                        </div>
                                      </div>
                                    </div>
                                  )}
                                </div>
                              ))}
                            </div>
                          </AccordionContent>
                        </AccordionItem>
                      ))}
                    </Accordion>
                  </div>
                </div>
              </ScrollArea>
            </div>
            
            {/* Page Corner Fold Effect */}
            <div className="absolute bottom-0 right-0 w-6 h-6 bg-gradient-to-tl from-[#D7CCC8] to-transparent pointer-events-none"></div>
          </Card>
        </section>

      </main>
    </div>
  );
}
