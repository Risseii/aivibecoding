# SQL Cottage: The Magic Terminal - Visual Concept

## 1. Aesthetic Direction: Cozy Cottagecore
**Tone:** Warm, inviting, organic, magical but grounded.
**Metaphor:** Programming is "writing magic spells" on an ancient stone tablet found in a hollowed-out tree.
**Protagonist:** **Moussie**, a studious field mouse with round spectacles and a worn leather satchel.

## 2. Color Palette
*   **Primary Backgrounds:** Warm Oak (`#4E342E`), Moss Green (`#33691E`), Cream/Parchment (`#F1F8E9`).
*   **Terminal/Editor:** Deep Slate (`#263238`) with Amber (`#FFCB6B`) or Soft Green (`#C3E88D`) text.
*   **Accents:** Cheese Gold (`#FFD54F`), Berry Red (Errors) (`#E57373`), Sky Blue (Magic) (`#4FC3F7`).

## 3. UI Structure & Layout

### A. Main Scene (The Nook)
The screen is framed by the interior of a tree trunk or wooden beams.
*   **Center Stage:** The **Magic Stone Terminal**.
    *   *Visuals:* A slab of dark slate embedded in a wooden desk.
    *   *Function:* This is the Code Editor and Result Output.
    *   *Styling:* Monospace font (rounded if possible), glowing text effect.
*   **Left Side:** **Moussie's Station**.
    *   Moussie stands here.
    *   *Idle:* Adjusting glasses, reading a tiny scroll.
    *   *Success:* Jumps up, sparkles appear.
    *   *Error:* Scratches head, looks at the user with a question mark.
*   **Right Side:** **The Guidebook (Schema & Quest)**.
    *   A leather-bound journal lying open.
    *   Shows the database tables (Schema) as "Magical Ingredients" or "Inventory".
    *   Shows the current objective (Quest).

### B. Feedback Mechanisms
*   **Success:**
    *   **Visual:** A piece of cheese floats into Moussie's satchel. The terminal glows golden.
    *   **Text:** "Spell cast successfully!"
*   **Error:**
    *   **Visual:** The terminal gives a little "shake" (CSS animation). A puff of gray smoke (particle effect).
    *   **Text:** "The magic fizzled..." followed by a helpful hint on parchment.

### C. Navigation (The Hub)
*   **Top Bar:** A wooden beam with hanging vines.
    *   **Progress:** A vine growing leaves (each leaf is a completed level).
    *   **Inventory:** Counter showing collected cheese wedges.
*   **Buttons:**
    *   "Run Code" -> A rune stone or a wooden button labeled "Cast".
    *   "Reset" -> A small eraser or broom icon.

## 4. Typography
*   **Headings:** Rounded Serif or Hand-written style (e.g., 'Patrick Hand', 'Comfortaa', 'Quicksand').
*   **Code:** Rounded Monospace (e.g., 'Fira Code' or 'Source Code Pro', styled with soft shadows).
*   **Body:** Readable Sans-serif with warm tones.

## 5. Micro-Interactions
*   **Hovering:** Buttons gently float or depress like wood.
*   **Typing:** Particle effects (tiny sparks) at the cursor position.
## 6. Level 1: Moussie's Grand Pantry

### Challenge 1: The Forgotten Inventory
*   **Context:** Moussie has just arrived at the pantry and wants to know what's there.
*   **Mission:** Show all supplies.
*   **Query:** `SELECT * FROM supplies;`
*   **Reward:** Fresh Cheese (Basic)
*   **Visual Success:** Moussie jumps for joy and drags the Fresh Cheese to her burrow.
*   **Visual Failure:** Moussie looks at an old map, confused.

### Challenge 2: Only the Tastiest
*   **Context:** Moussie is looking for the essentials.
*   **Mission:** Select only the names of the supplies.
*   **Query:** `SELECT name FROM supplies;`
*   **Reward:** Aged Cheddar
*   **Visual Success:** Moussie jumps for joy and drags the Aged Cheddar to her burrow.
*   **Visual Failure:** Moussie looks at an old map, confused.

### Challenge 3: The Lost Cheese
*   **Context:** Moussie has a specific craving.
*   **Mission:** Find all supplies that are in the category 'Cheese'.
*   **Query:** `SELECT * FROM supplies WHERE category = 'Cheese';`
*   **Reward:** Smoked Gouda
*   **Visual Success:** Moussie jumps for joy and drags the Smoked Gouda to her burrow.
*   **Visual Failure:** Moussie looks at an old map, confused.

### Challenge 4: Hunger Emergency!
*   **Context:** Lots of food is needed fast!
*   **Mission:** Find the names of supplies with a quantity greater than 10.
*   **Query:** `SELECT name FROM supplies WHERE quantity > 10;`
*   **Reward:** Parmesan
*   **Visual Success:** Moussie jumps for joy and drags the Parmesan to her burrow.
*   **Visual Failure:** Moussie looks at an old map, confused.

### Challenge 5: Ordering the Chaos
*   **Context:** Moussie wants to organize her favorite cheeses.
*   **Mission:** Show the cheeses ordered by quantity from highest to lowest.
*   **Query:** `SELECT * FROM supplies WHERE category = 'Cheese' ORDER BY quantity DESC;`
*   **Reward:** Mountain Blue Cheese
*   **Visual Success:** Moussie jumps for joy and drags the Mountain Blue Cheese to her burrow.
*   **Visual Failure:** Moussie looks at an old map, confused.
